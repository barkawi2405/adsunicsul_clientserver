package br.com.projeto.projeto.exception;

public class NotFoundException extends RuntimeException {
	private static final long serialVersionUID = 4434243638181134638L;

	public NotFoundException(String msg) {
		super(msg);
	}
	
	public NotFoundException(String msg, Throwable cause) {
		super(msg, cause);
	}
}