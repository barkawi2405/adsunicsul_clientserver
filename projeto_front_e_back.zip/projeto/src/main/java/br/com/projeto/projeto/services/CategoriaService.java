package br.com.projeto.projeto.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projeto.projeto.domain.Categoria;
import br.com.projeto.projeto.repository.CategoriaRepository;

@Service
public class CategoriaService {
	
	@Autowired
	private CategoriaRepository categoriaRepository;
	
	public List<Categoria> findAllCategorias() {
		return categoriaRepository.findAll(); 
	}
}
