package br.com.projeto.projeto.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projeto.projeto.domain.Livro;
import br.com.projeto.projeto.exception.NotFoundException;
import br.com.projeto.projeto.repository.LivroRepository;

@Service
public class LivroService {

	@Autowired
	private LivroRepository livroRepository;
	
	public List<Livro> getAllLivrosByCategoria(String categoria) {
		
		return livroRepository.findLivrosByCategoria(categoria);
	}
	
	public Livro getLivroById(Long id) {
		return livroRepository.findById(id).orElseThrow(() -> new NotFoundException("Livro não encontrado"));
	}
	
	public Livro saveLivro(Livro livro) {
		return livroRepository.save(livro);
	}
	
	public Livro updateLivro(Livro livro) {
		Livro newLivro = getLivroById(livro.getCodlivro());
		updateData(livro, newLivro);
		
		return livroRepository.save(newLivro);
	}
	
	private void updateData(Livro obj, Livro newObj) {
		newObj.setTitulo(obj.getTitulo());
		newObj.setAutor(obj.getAutor());
		newObj.setCategoria(obj.getCategoria());
		newObj.setValor(obj.getValor());
	}
	
	public void deleteLivroById(Long id) {
		getLivroById(id);
		
		livroRepository.deleteById(id);
	}
}