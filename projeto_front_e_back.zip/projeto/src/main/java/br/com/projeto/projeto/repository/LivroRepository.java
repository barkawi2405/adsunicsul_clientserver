package br.com.projeto.projeto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.projeto.domain.Livro;

@Repository
public interface LivroRepository extends JpaRepository<Livro, Long> {
	
	List<Livro> findLivrosByCategoria(String categoria);
}
