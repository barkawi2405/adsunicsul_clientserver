package br.com.projeto.projeto.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbcategorias")
public class Categoria {
	
	@Id
	private String categoria;

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Categoria(String categoria) {
		super();
		this.categoria = categoria;
	}

	public Categoria() {
	}
}
