package br.com.projeto.projeto.controller;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.projeto.projeto.domain.Livro;
import br.com.projeto.projeto.services.LivroService;

@RestController
@RequestMapping(value = "/livros")
public class LivroController {

	@Autowired
	private LivroService livroService;
	
	@RequestMapping(value= "/categoria/{categoria}", method=RequestMethod.GET)
	public ResponseEntity<List<Livro>> findByCategoria(@PathVariable final String categoria) {
		List<Livro> livros = livroService.getAllLivrosByCategoria(categoria);
		
		return ResponseEntity.ok().body(livros);
	}
	
	@RequestMapping(value= "/{id}", method=RequestMethod.GET)
	public ResponseEntity<Livro> findById(@PathVariable final Long id) {
		Livro livro = livroService.getLivroById(id);
		
		return ResponseEntity.ok().body(livro);
	}
	
	@RequestMapping(value = "/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<Void> delete(@PathVariable final Long id) {
		livroService.deleteLivroById(id);

		return ResponseEntity.noContent().build();
	} 
	
	@RequestMapping(value = "/{id}", method=RequestMethod.PUT)
	public ResponseEntity<Void> update(
			@Valid @RequestBody Livro livro,
			@PathVariable Long id) {
		livro.setCodlivro(id);
		livroService.updateLivro(livro);

		return ResponseEntity.noContent().build();
	} 
	
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<Void> save(@Valid @RequestBody Livro livro) {
		Livro savedLivro = livroService.saveLivro(livro);
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
				.path("/{id}").buildAndExpand(savedLivro.getCodlivro())
				.toUri();
		
		return ResponseEntity.created(uri).build();
	}
}
