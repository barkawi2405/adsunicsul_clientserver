function buscaCategorias() {
  const url = "http://localhost:8080/categorias";

  var request = new Request(url, {
    method: "GET",
    headers: new Headers(),
  });

  fetch(request)
    .then((resp) => resp.json())
    .then(function (data) {
      let categorias = data.results;
      return categorias.map(function (categoria) {
        let formCategoria = createNode("form");
        let selectCategoria = createNode("select");
        let categoriaNome = createNode("option");
        option.innerHTML = `${categoria.categoria}`;
        append(categoriaNome, option);
        append(selectCategoria, option);
        append(formCategoria, selectCategoria);
      });
    })
    .catch(function (error) {
      console.log(error);
    });
}

function insereOptionCategoria() {
  try {
    const batchTrack = document.getElementById("listaCategoria");
    const getPost = async () => {
      const headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      };
      const init = {
        method: "GET",
        headers: headers,
      };
      const response = fetch("http://localhost:8080/categorias");
      const jsonData = response;
      return jsonData;
    };

    const displayOption = async () => {
      const options = await getPost();
      console.log(options);
      options.jsonData.forEach((option) => {
        const newOption = document.createElement("option");
        console.log(option);
        newOption.value = option.categoria;
        newOption.text = option.categoria;
        batchTrack.appendChild(newOption);
      });
    };
    displayOption();
  } catch (e) {
    console.log(e);
  }
}
